
export class Student {
    id?= 0;
    name = "";
    gender = "m";
    country = "";
    city = "";
}
