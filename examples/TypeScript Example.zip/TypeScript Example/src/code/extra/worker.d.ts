declare module "file-loader?name=scripts/[name].[hash].js!*" {
    const value: string;
    export = value;
}