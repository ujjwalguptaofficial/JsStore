# Introduction

This is an example of using jsstore with typescript.

# How to run

1. execute `npm install` - install all dependecies
2. execute `npm run start` - run the dev server
3. browse url - `http://localhost:8080/`